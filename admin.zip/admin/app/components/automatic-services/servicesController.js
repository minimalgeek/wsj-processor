adminApp.controller("servicesController", function ($scope, dataDownloaderService) {
    $scope.data = {

    }
});